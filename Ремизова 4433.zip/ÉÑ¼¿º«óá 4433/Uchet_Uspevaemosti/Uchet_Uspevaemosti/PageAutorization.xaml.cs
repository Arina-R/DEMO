﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Uchet_Uspevaemosti
{
    /// <summary>
    /// Логика взаимодействия для PageAutorization.xaml
    /// </summary>
    public partial class PageAutorization : Page
    {
        public PageAutorization()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (Login_TB.Text == "user05" && Password_TB.Text == "asdfgh")
            {
                Manager.MainFrame.Navigate(new TeacherPage());
            }
            else
            {
                if (Login_TB.Text == "user01" && Password_TB.Text == "qwerty")
                {
                    Manager.MainFrame.Navigate(new StudentPage());
                }
            }
            
        }
    }
}
